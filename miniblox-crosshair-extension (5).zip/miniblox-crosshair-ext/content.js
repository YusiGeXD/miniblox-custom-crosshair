// =============================================
//  Miniblox Crosshair Changer — content.js v3
// =============================================

const STORAGE_KEY = "mcx_settings";
const DEFAULT = {
  style: "cross", color: "#00ffcc", size: 20,
  thickness: 2, opacity: 1.0, gap: 4,
  outline: true, outlineColor: "#000000", dotCenter: true,
};

function getSettings(cb) {
  chrome.storage.local.get(STORAGE_KEY, (d) => cb(Object.assign({}, DEFAULT, d[STORAGE_KEY] || {})));
}

// ── PAGE CONTEXT INJECTION ────────────────────────────────────────────────────
// Canvas 2D prototype hook — oyun her frame crosshair çizdiğinde yakalarız
function injectPageScript() {
  const s = document.createElement("script");
  s.textContent = `(function () {
  const _stroke      = CanvasRenderingContext2D.prototype.stroke;
  const _fill        = CanvasRenderingContext2D.prototype.fill;
  const _strokeRect  = CanvasRenderingContext2D.prototype.strokeRect;
  const _fillRect    = CanvasRenderingContext2D.prototype.fillRect;
  const _drawImage   = CanvasRenderingContext2D.prototype.drawImage;

  // Ekranın ortasına yakın bir canvas çizimi mi?
  function isCenterDraw(ctx) {
    const c   = ctx.canvas;
    const t   = ctx.getTransform ? ctx.getTransform() : null;
    const cw2 = c.width  / 2;
    const ch2 = c.height / 2;
    // transform'un translation'ı merkeze yakınsa crosshair olarak say
    if (t) {
      const dx = Math.abs(t.e - cw2);
      const dy = Math.abs(t.f - ch2);
      if (dx < 60 && dy < 60) return true;
    }
    return false;
  }

  // Küçük, merkeze yakın fillRect → crosshair arka planı olabilir
  CanvasRenderingContext2D.prototype.fillRect = function(x, y, w, h) {
    const cw2 = this.canvas.width  / 2;
    const ch2 = this.canvas.height / 2;
    const cx  = x + w / 2, cy = y + h / 2;
    if (Math.abs(cx - cw2) < 60 && Math.abs(cy - ch2) < 60 && w < 80 && h < 80) return;
    return _fillRect.apply(this, arguments);
  };

  CanvasRenderingContext2D.prototype.strokeRect = function(x, y, w, h) {
    const cw2 = this.canvas.width  / 2;
    const ch2 = this.canvas.height / 2;
    const cx  = x + w / 2, cy = y + h / 2;
    if (Math.abs(cx - cw2) < 60 && Math.abs(cy - ch2) < 60 && w < 80 && h < 80) return;
    return _strokeRect.apply(this, arguments);
  };

  CanvasRenderingContext2D.prototype.stroke = function() {
    if (isCenterDraw(this)) return;
    return _stroke.apply(this, arguments);
  };

  CanvasRenderingContext2D.prototype.fill = function() {
    if (isCenterDraw(this)) return;
    return _fill.apply(this, arguments);
  };

  // drawImage ile sprite olarak çizilen crosshairlar
  CanvasRenderingContext2D.prototype.drawImage = function(img, ...args) {
    // Küçük sprite + merkeze yakın → atla
    const cw2 = this.canvas.width / 2, ch2 = this.canvas.height / 2;
    if (args.length >= 2) {
      const dx = args[0], dy = args[1];
      const dw = args[2] || (img.width  || 64);
      const dh = args[3] || (img.height || 64);
      const cx = dx + dw / 2, cy = dy + dh / 2;
      if (Math.abs(cx - cw2) < 60 && Math.abs(cy - ch2) < 60 && dw < 80 && dh < 80) return;
    }
    return _drawImage.apply(this, arguments);
  };

  console.log('[MCX] Canvas 2D hooks active');
})();`;
  (document.head || document.documentElement).appendChild(s);
  s.remove();
}

// ── DOM FALLBACK ──────────────────────────────────────────────────────────────
const SELECTORS = [
  "svg[viewBox=\"0 0 726 628\"]",
  "svg[height=\"25\"][width=\"25\"]",
  "#crosshair",".crosshair","#hud-crosshair",
  "[id*='crosshair']","[class*='crosshair']",
  "[id*='reticle']","[class*='reticle']",
  "[id*='cursor']","[class*='cursor']",
  "[id*='aim']","[class*='aim']",
  "#cross",".cross-hair",
];

function hideDOM() {
  SELECTORS.forEach(sel => {
    try {
      document.querySelectorAll(sel).forEach(el => {
        el.style.setProperty("opacity","0","important");
        el.style.setProperty("visibility","hidden","important");
      });
    } catch {}
  });
}

// ── OUR CROSSHAIR ─────────────────────────────────────────────────────────────
function seg(color, opacity, shadow, styles) {
  const d = document.createElement("div");
  Object.assign(d.style, {
    position:"fixed", pointerEvents:"none", zIndex:"2147483647",
    background: color, opacity: String(opacity), boxShadow: shadow,
    ...styles
  });
  return d;
}

function buildCrosshair(s) {
  const wrap = document.createElement("div");
  wrap.id = "mcx-wrap";
  const sh  = s.outline ? `0 0 0 1px ${s.outlineColor}` : "none";
  const half = s.size / 2;
  const base = { position:"fixed", pointerEvents:"none", zIndex:"2147483647", top:"50%", left:"50%" };

  const mkSeg = (styles) => seg(s.color, s.opacity, sh, styles);

  if (s.style === "dot") {
    const r = s.thickness * 1.5;
    wrap.appendChild(mkSeg({ ...base, width:`${r*2}px`, height:`${r*2}px`,
      borderRadius:"50%", transform:"translate(-50%,-50%)" }));

  } else if (s.style === "circle") {
    const d = document.createElement("div");
    Object.assign(d.style, { ...base, width:`${s.size}px`, height:`${s.size}px`,
      border:`${s.thickness}px solid ${s.color}`, borderRadius:"50%",
      opacity:String(s.opacity), boxShadow:sh, background:"transparent",
      transform:"translate(-50%,-50%)", position:"fixed", pointerEvents:"none", zIndex:"2147483647" });
    wrap.appendChild(d);
    if (s.dotCenter) wrap.appendChild(mkSeg({ ...base,
      width:`${s.thickness*2}px`, height:`${s.thickness*2}px`,
      borderRadius:"50%", transform:"translate(-50%,-50%)" }));

  } else if (s.style === "cross" || s.style === "custom") {
    const g = s.gap;
    if (g > 0) {
      wrap.appendChild(mkSeg({ width:`${half-g}px`, height:`${s.thickness}px`, top:"50%", left:`calc(50% - ${half}px)`, transform:"translateY(-50%)" }));
      wrap.appendChild(mkSeg({ width:`${half-g}px`, height:`${s.thickness}px`, top:"50%", left:`calc(50% + ${g}px)`,    transform:"translateY(-50%)" }));
      wrap.appendChild(mkSeg({ width:`${s.thickness}px`, height:`${half-g}px`, left:"50%", top:`calc(50% - ${half}px)`, transform:"translateX(-50%)" }));
      wrap.appendChild(mkSeg({ width:`${s.thickness}px`, height:`${half-g}px`, left:"50%", top:`calc(50% + ${g}px)`,    transform:"translateX(-50%)" }));
    } else {
      wrap.appendChild(mkSeg({ width:`${s.size}px`, height:`${s.thickness}px`, top:"50%", left:`calc(50% - ${half}px)`, transform:"translateY(-50%)" }));
      wrap.appendChild(mkSeg({ width:`${s.thickness}px`, height:`${s.size}px`, left:"50%", top:`calc(50% - ${half}px)`, transform:"translateX(-50%)" }));
    }
    if (s.dotCenter) wrap.appendChild(mkSeg({ ...base,
      width:`${s.thickness*2}px`, height:`${s.thickness*2}px`,
      borderRadius:"50%", transform:"translate(-50%,-50%)" }));

  } else if (s.style === "tcross") {
    wrap.appendChild(mkSeg({ width:`${s.size}px`, height:`${s.thickness}px`, top:"50%", left:`calc(50% - ${half}px)`, transform:"translateY(-50%)" }));
    wrap.appendChild(mkSeg({ width:`${s.thickness}px`, height:`${half - s.gap}px`, left:"50%", top:`calc(50% + ${s.gap}px)`, transform:"translateX(-50%)" }));
  }

  return wrap;
}

function render() {
  const old = document.getElementById("mcx-wrap");
  if (old) old.remove();
  getSettings(s => document.body.appendChild(buildCrosshair(s)));
}

// ── INIT ──────────────────────────────────────────────────────────────────────
function init() {
  injectPageScript();
  render();
  hideDOM();
  setInterval(hideDOM, 800);
  new MutationObserver(hideDOM).observe(document.body, { childList:true, subtree:true });
  chrome.storage.onChanged.addListener(ch => { if (ch[STORAGE_KEY]) render(); });
  document.addEventListener("pointerlockchange", () => {
    const w = document.getElementById("mcx-wrap");
    if (w) w.style.display = document.pointerLockElement ? "" : "none";
  });
}

document.readyState === "loading"
  ? document.addEventListener("DOMContentLoaded", init)
  : init();
