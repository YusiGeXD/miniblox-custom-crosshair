// popup.js — Crosshair ayar paneli

const KEY = "mcx_settings";
const DEFAULT = {
  style: "cross", color: "#00ffcc", size: 20,
  thickness: 2, opacity: 1.0, gap: 4,
  outline: true, outlineColor: "#000000", dotCenter: true,
};

let settings = { ...DEFAULT };

// ---------- DOM refs ----------
const colorPicker = document.getElementById("color-picker");
const sizeEl      = document.getElementById("size");
const thickEl     = document.getElementById("thickness");
const gapEl       = document.getElementById("gap");
const opacityEl   = document.getElementById("opacity");
const outlineEl   = document.getElementById("outline");
const dotEl       = document.getElementById("dot-center");
const canvas      = document.getElementById("preview-canvas");
const ctx         = canvas.getContext("2d");

// ---------- yükle ----------
chrome.storage.local.get(KEY, (data) => {
  settings = Object.assign({}, DEFAULT, data[KEY] || {});
  applyToUI();
  drawPreview();
});

function applyToUI() {
  const s = settings;
  colorPicker.value = s.color;
  sizeEl.value      = s.size;
  thickEl.value     = s.thickness;
  gapEl.value       = s.gap;
  opacityEl.value   = Math.round(s.opacity * 100);
  outlineEl.checked = s.outline;
  dotEl.checked     = s.dotCenter;

  document.getElementById("lbl-size").textContent    = s.size;
  document.getElementById("lbl-thick").textContent   = s.thickness;
  document.getElementById("lbl-gap").textContent     = s.gap;
  document.getElementById("lbl-opacity").textContent = Math.round(s.opacity * 100) + "%";

  document.querySelectorAll(".pill").forEach(p => {
    p.classList.toggle("active", p.dataset.val === s.style);
  });
  document.querySelectorAll(".swatch").forEach(sw => {
    sw.classList.toggle("active", sw.dataset.color === s.color);
  });

  // Gap sadece cross / tcross / custom için
  document.getElementById("gap-section").style.display =
    ["dot", "circle"].includes(s.style) ? "none" : "";
}

// ---------- kaydet ----------
function save() {
  chrome.storage.local.set({ [KEY]: settings }, () => {
    applyToUI();
    drawPreview();
  });
}

// ---------- preview ----------
function drawPreview() {
  const s = settings;
  const w = canvas.width, h = canvas.height;
  const cx = w / 2, cy = h / 2;

  ctx.clearRect(0, 0, w, h);

  ctx.globalAlpha = s.opacity;
  ctx.strokeStyle = s.color;
  ctx.fillStyle   = s.color;
  ctx.lineWidth   = s.thickness;

  if (s.outline) {
    ctx.shadowColor = s.outlineColor;
    ctx.shadowBlur  = 2;
  } else {
    ctx.shadowBlur = 0;
  }

  const half = s.size / 2;
  const gap  = s.gap;

  if (s.style === "dot") {
    ctx.beginPath();
    ctx.arc(cx, cy, s.thickness * 1.5, 0, Math.PI * 2);
    ctx.fill();

  } else if (s.style === "circle") {
    ctx.beginPath();
    ctx.arc(cx, cy, half, 0, Math.PI * 2);
    ctx.stroke();
    if (s.dotCenter) { ctx.beginPath(); ctx.arc(cx, cy, s.thickness, 0, Math.PI * 2); ctx.fill(); }

  } else if (s.style === "cross" || s.style === "custom") {
    ctx.beginPath();
    if (gap > 0) {
      ctx.moveTo(cx - half, cy); ctx.lineTo(cx - gap, cy);
      ctx.moveTo(cx + gap, cy);  ctx.lineTo(cx + half, cy);
      ctx.moveTo(cx, cy - half); ctx.lineTo(cx, cy - gap);
      ctx.moveTo(cx, cy + gap);  ctx.lineTo(cx, cy + half);
    } else {
      ctx.moveTo(cx - half, cy); ctx.lineTo(cx + half, cy);
      ctx.moveTo(cx, cy - half); ctx.lineTo(cx, cy + half);
    }
    ctx.stroke();
    if (s.dotCenter) { ctx.beginPath(); ctx.arc(cx, cy, s.thickness, 0, Math.PI * 2); ctx.fill(); }

  } else if (s.style === "tcross") {
    ctx.beginPath();
    ctx.moveTo(cx - half, cy); ctx.lineTo(cx + half, cy);
    ctx.moveTo(cx, cy + gap);  ctx.lineTo(cx, cy + half);
    ctx.stroke();
  }

  ctx.globalAlpha = 1;
  ctx.shadowBlur  = 0;
}

// ---------- event listeners ----------

// Stil pills
document.getElementById("style-pills").addEventListener("click", (e) => {
  const p = e.target.closest(".pill");
  if (!p) return;
  settings.style = p.dataset.val;
  save();
});

// Renk picker
colorPicker.addEventListener("input", (e) => {
  settings.color = e.target.value;
  document.querySelectorAll(".swatch").forEach(sw => sw.classList.remove("active"));
  save();
});

// Swatches
document.getElementById("swatches").addEventListener("click", (e) => {
  const sw = e.target.closest(".swatch");
  if (!sw) return;
  settings.color = sw.dataset.color;
  colorPicker.value = settings.color;
  save();
});

// Range inputs
const ranges = [
  { el: sizeEl,    key: "size",      lbl: "lbl-size",    fmt: v => v },
  { el: thickEl,   key: "thickness", lbl: "lbl-thick",   fmt: v => v },
  { el: gapEl,     key: "gap",       lbl: "lbl-gap",     fmt: v => v },
  { el: opacityEl, key: "opacity",   lbl: "lbl-opacity", fmt: v => v + "%" },
];

ranges.forEach(({ el, key, lbl, fmt }) => {
  el.addEventListener("input", (e) => {
    const raw = parseInt(e.target.value);
    document.getElementById(lbl).textContent = fmt(raw);
    settings[key] = key === "opacity" ? raw / 100 : raw;
    save();
  });
});

// Toggles
outlineEl.addEventListener("change", () => { settings.outline = outlineEl.checked; save(); });
dotEl.addEventListener("change",     () => { settings.dotCenter = dotEl.checked;   save(); });
